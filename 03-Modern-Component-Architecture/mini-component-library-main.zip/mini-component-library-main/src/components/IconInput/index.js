export { default } from './IconInput';
