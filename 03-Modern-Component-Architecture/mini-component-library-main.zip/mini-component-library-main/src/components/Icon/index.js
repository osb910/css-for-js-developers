export { default } from './Icon';
